# Harmony — Pillar 1 Team Brief
## Spatial Substrate · Identity System
**Version:** 1.0  
**Status:** Active — Ready for skill execution  
**Pillar:** 1 of 5  
**Spec source:** Master Specification V1.0.1 · Stage 1 Brief V0.1.1

---

## What Pillar 1 Is

Pillar 1 builds the Harmony Identity System — the addressing backbone that every other pillar depends on. Before any data can be ingested, rendered, queried, or interacted with, every spatial object in the world needs a stable, resolvable, machine-readable identity.

Nothing in Pillars 2–5 can scale cleanly without this system being correct.

---

## The Five Active Roles

| Role | Agent | Tool | Pillar 1 Responsibility |
|------|-------|------|------------------------|
| Principal Architect | Dr. Mara Voss | Claude Chat | Decision gates, ADR authority, schema lock |
| Spatial Engineer | Unnamed agent | Claude Code | Cell key derivation, cell registration, HCID |
| PM Orchestrator | Unnamed agent | Claude CoWork | Milestone tracking, session routing, dashboard updates |
| ADR Agent | Unnamed agent | Claude Chat | Decision records, Gap Register, drift detection |
| QA Agent | Unnamed agent | Claude Code | Test suites, acceptance validation, integration checks |

---

## Decisions Already Locked (Do Not Re-Open)

These are binding. Any agent that proposes revisiting these is out of scope.

| Decision | Resolution | ADR |
|----------|-----------|-----|
| Spatial indexing system | Custom Harmony Cell System — not H3, not S2 | VAR-009 |
| Identity encoding | Six-layer model: Canonical ID → Cell Key → Human Alias → Friendly Name → Known Names → Semantic Labels | VAR-001 |
| Dual-identifier design | Every cell carries both `cell_id` (immutable opaque) and `cell_key` (deterministic, derivable) | VAR-002 |
| Bitemporal versioning | Reserved at schema layer now. Four fields present: `valid_from`, `valid_to`, `version_of`, `temporal_status`. Activation owned by Pillar 4 | VAR-003 |
| Federation compatibility | Canonical ID format carries no embedded operator or jurisdiction. Supports future federated model without breaking changes | VAR-005 |
| Hashing algorithm | BLAKE3 for cell key derivation | ADR-009 |
| Encoding format | Crockford Base32, 16 characters | ADR-009 |
| Coordinate system | ECEF for global cell key derivation · ENU for local in-cell reasoning | Locked |
| Cell hierarchy | Gnomonic cube projection · 12 resolution levels · 16-child fan-out | Locked |

---

## Open Decisions (Must Be Resolved Before Build)

These are the remaining gate items. The Principal Architect resolves them in the first session.

| Gate | Decision | Urgency |
|------|----------|---------|
| Gate 2 | Cell granularity — metric edge lengths per resolution level | Pre-Sprint 1 |
| Gate 3 | Identity encoding method — hybrid prefix-plus-random-suffix scheme (recommended, pending confirmation) | Pre-Sprint 1 |

---

## The Six Milestones

| # | Milestone | Owner | Deliverable |
|---|-----------|-------|-------------|
| 1 | Identity Schema Lock | Principal Architect + ADR Agent | `identity-schema.md`, `cell_identity_schema.json`, `entity_identity_schema.json`, ADRs 001/004/008 |
| 2 | Registry Service (Local) | Spatial Engineer | `identity_registry_schema.sql`, migrations, CRUD operations, canonical lookup |
| 3 | Alias System | Spatial Engineer | `alias_namespace_rules.md`, alias generation, namespace resolution, ambiguity handling |
| 4 | Cell Identity Integration | Spatial Engineer | `cell_id` + `cell_key` linkage, `sample-central-coast-records.json` |
| 5 | API Layer | Spatial Engineer | Resolve + register endpoints, `resolution_service_spec.md` |
| 6 | End-to-End Test | QA Agent | Alias → canonical → entity → cell resolution flow, all acceptance criteria passing |

---

## Acceptance Criteria (Non-Negotiable)

Pillar 1 is complete only when all of the following are true:

- [ ] Alias resolves to canonical ID
- [ ] Canonical ID resolves to full metadata record
- [ ] Every cell has BOTH `cell_id` and deterministic `cell_key`
- [ ] Entity links to primary and secondary cells
- [ ] Alias can change without breaking canonical identity
- [ ] Lifecycle states are enforced (active / deprecated / archived)
- [ ] Namespace collisions are detected and handled
- [ ] Registry acts as single source of truth
- [ ] Sample Central Coast records pass end-to-end resolution

---

## What Pillar 1 Unlocks

Once these acceptance criteria pass:

- **Pillar 2** — Data ingestion can attach datasets to cells
- **Pillar 3** — Rendering can resolve spatial context from the registry
- **Pillar 4** — Knowledge layer can attach meaning and temporal state to entities
- **Pillar 5** — Interaction layer can resolve user intent against canonical identities

---

## Pinned Principle

> Canonical IDs are for truth. Aliases are for people. Semantic labels are for intelligence.

---

## Skill Execution Order

1. **Principal Architect** runs first — resolves Gates 2 & 3, locks schema, produces ADRs
2. **ADR Agent** runs in parallel — records every decision, flags any drift
3. **Spatial Engineer** runs after schema lock — builds registry, alias system, cell key derivation, API
4. **QA Agent** runs after each milestone — generates tests, validates outputs
5. **PM Orchestrator** runs throughout — tracks milestones, routes tasks, produces session summaries for dashboard

---

*Harmony Pillar 1 Team Brief V1.0 · April 2026 · Internal*
