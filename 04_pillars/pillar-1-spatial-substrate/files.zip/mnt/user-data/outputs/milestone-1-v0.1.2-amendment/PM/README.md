# Project Management Infrastructure

> **Purpose:** Provide Mikey (Founder/PM) with a structured, scannable record of every CoWork session and a daily briefing that surfaces what needs attention.
>
> **Owner:** Builder PM Agent (see `agents/project-manager-agent-brief.md`)
> **Established:** 2026-04-10 (v0.1.2 amendment)

---

## Folder Structure

```
PM/
├── README.md                              ← this file
├── agents/
│   └── project-manager-agent-brief.md     ← PM Agent role, inputs, outputs
├── templates/
│   └── session-progress-report-template.md ← format every session follows
├── sessions/                              ← per-session reports, written by Builder Agents
│   ├── 2026-04-10-pillar-1-v0.1.2-amendment.md
│   └── ...
├── daily-briefings/                       ← per-day summaries, written by PM Agent
│   └── 2026-04-11.md
├── decisions/                             ← log of decisions made and pending
│   └── pending-decisions.md
└── timeline/                              ← Gantt and timeline artifacts
    ├── master-gantt.md
    └── pillar-progress.md
```

---

## How This Works

### 1. Builder Agents write session reports

Every meaningful CoWork or Code session — meaning any session that produces real artifacts (code, schemas, ADRs, decisions, research findings) — ends with the active Builder Agent writing a **Session Progress Report** to `PM/sessions/`.

The filename format is:

```
PM/sessions/YYYY-MM-DD-pillar-N-short-description.md
```

Example: `PM/sessions/2026-04-10-pillar-1-v0.1.2-amendment.md`

The report follows the template in `templates/session-progress-report-template.md`. Sections are consistent across reports so the PM Agent (and Mikey) can read across sessions without learning a new format each time.

### 2. The PM Agent runs daily

Once per day, the Project Manager Agent reads everything new in `PM/sessions/` since its last run, plus any updates to `PM/decisions/` and `PM/timeline/`. It produces a single **Daily Briefing** in `PM/daily-briefings/` summarising:

- What got done since yesterday
- What's blocked and why
- What decisions are waiting on Mikey, ranked by urgency
- What's about to need a decision in the next 1–3 days
- Any drift from the plan
- **PM Opinion** — clearly marked, on schedule risk, scope drift, blockers, and ecosystem-level recommendations

### 3. Mikey reads the daily briefing

The briefing is the primary interface between Mikey and the project. It is short, scannable, ranked by what matters most that day. Mikey's actions:

- Read the briefing
- Make any decisions waiting on him (responses logged in `PM/decisions/`)
- Update priorities if needed
- Schedule any required CoWork sessions for the day

### 4. The cycle repeats

Builder Agents act on the day's priorities, write session reports as they finish work, and the PM Agent picks them up tomorrow.

---

## File Conventions

### Session reports

- Filenames: `YYYY-MM-DD-pillar-N-short-description.md`
- One session = one report, even if the session was long
- Reports are written **at the end** of the session, by the active Builder Agent
- Reports must follow the template — no creative reformatting
- Reports are append-only: never edit a past session report; if something changes, write a new one and reference the old

### Daily briefings

- Filenames: `YYYY-MM-DD.md`
- Written by the PM Agent only
- Briefings are short — target 300–600 words including the opinion section
- If nothing meaningful happened in a 24-hour period, the briefing says so explicitly

### Decisions log

- `decisions/pending-decisions.md` is a living list of decisions awaiting Mikey
- Each entry: decision description, who needs it, urgency, deadline if any, recommended option
- Resolved decisions move to `decisions/resolved/YYYY-MM-DD-decision-name.md`

### Timeline

- `timeline/master-gantt.md` is the project Gantt, maintained by the PM Agent
- `timeline/pillar-progress.md` tracks each pillar's milestone status
- Updated by the PM Agent as part of the daily briefing run

---

## What This Folder Is Not For

- **Not for code or schemas.** Those live in their pillar folders. PM is metadata about the project, not the project itself.
- **Not for design documents.** ADRs live alongside the schemas they describe, not in PM.
- **Not for chat transcripts.** Session reports are summaries, not transcripts.
- **Not a replacement for ADRs.** Decisions captured in PM are *project management* decisions (what to work on, when, with what priority) — not architectural decisions, which still go in ADRs.

---

## First Session

The first session report is `sessions/2026-04-10-pillar-1-v0.1.2-amendment.md`, covering this v0.1.2 amendment work. It is the seed that lets the PM Agent start producing daily briefings.

---

*PM Infrastructure — established v0.1.2*
